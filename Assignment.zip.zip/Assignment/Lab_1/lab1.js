const questionOne = function questionOne(arr) {

    var sum=0;
    var t;
    for(var i=0;i<arr.length;i++){
        if(isNaN(arr[i])){ // to check input array `consist of number or not
            return 'Not a number, entered a specied number' // will return that its not a number 
        
        }else 
        { // squaring and addition of number
            
        t=arr[i]*arr[i]; // squaring
        sum=sum+t; //addition
        }

    }

    return sum
   
}

const questionTwo = function questionTwo(num)
 {
    if(num==1) //checks if index is or 1 or not
    {
    var sum=1;
    }
    else
    {
        if(typeof(num)=='string')       //check if index is character or string or symbol
        {
           return ("Please enter a number, not a character or string or symbol")
        }
        else
        {               // calculating Fibonacci series with N index
            sum=0;
                var a=0,b=1;
                for(var x=0;x<num-1;x++)
                {
                    sum=a+b;
                    a=b;
                    b=sum;
                }
                
        }
    } 
  
    return sum
}

const questionThree = function questionThree(str) {
    var count=0;
    
    var str1=str.toString()
    for(var i=0;i<str.length-1;i++)
    {
        if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u'||
        str.charAt(i)=='A'||str.charAt(i)=='E'||str.charAt(i)=='I'||str.charAt(i)=='O'||str.charAt(i)=='U') // checking for vowels
        {
            count++ ;       
        }
        
    }return count
  
    
}

const questionFour = function questionFour(num) 
{   if(num<0) // for negative number 
    {
        return NaN;
    }else
    {
        if(num==0) // for zero 
        {
            return 1;
        }
        else
        { 
            return(num*questionFour(num-1)) //recurive calling creating factorial series  
        }

    }

}

module.exports = {
    firstName: "YASH", 
    lastName: "DAFTARDAR", 
    studentId: "10453472",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};