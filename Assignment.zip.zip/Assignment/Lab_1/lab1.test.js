const lab1 = require("./lab1");


console.log(lab1.questionOne([1, 2, 3]));           // should output 14
console.log(lab1.questionOne([5, 3, 10]));          // should output 134
console.log(lab1.questionOne([2, 1, 2]));           // should output 9
console.log(lab1.questionOne([5, 10, 9]));          // should output 206
console.log(lab1.questionOne([5, 10, 10]));         // should output 225
//console.log(lab1.questionOne(['a', 'y', 'z']));     //not a number ,should output 0




console.log(lab1.questionTwo(7));       // should output 13 
console.log(lab1.questionTwo(1));       // should output 1
console.log(lab1.questionTwo(0));       // should output 0   
console.log(lab1.questionTwo(-1));      // should output 0
//console.log(lab1.questionTwo('abc'));   // should output Please enter a number, not a character or string or symbol
//console.log(lab1.questionTwo('.'));     // should output Please enter a number, not a character or string or symbol


console.log(lab1.questionThree("Mr. and Mrs. Dursley, of number four, Privet Drive, were  proud  to  say  that  they  were  perfectly  normal,  thank you  very  much. They  were  the  last  people  youd  expect  to  be  involved in anything strange or mysterious, because they just didn't hold with such nonsense. \n Mr. Dursley was the director of a firm called Grunnings, which  made  drills.  He  was  a  big,  beefy  man  with  hardly  any  neck,  although he did have a very large mustache. Mrs. Dursley was thin and blonde and had nearly twice the usual amount of neck, which came in very useful as she spent so much of her time craning over garden fences, spying on the neighbors. The Dursleys had a small son  called  Dudley  and  in  their  opinion  there  was no finer boy anywhere.")); 
// should output 196

console.log(lab1.questionThree("Mooooose"));
//console.log(lab1.questionThree("In this line there extra a,e,i,o,u."));     // should output 13
//console.log(lab1.questionThree(1,3,2));


console.log(lab1.questionFour(10));    // output 3628800 
console.log(lab1.questionFour(1));     // output 1 
console.log(lab1.questionFour(0));     // output 1 
console.log(lab1.questionFour(-1));    // output NaN 
//console.log(lab1.questionFour(2));     // output 2
//console.log(lab1.questionFour(3));     // output 6
//console.log(lab1.questionFour(4));      // output 24
//console.log(lab1.questionFour(5));      // output 120