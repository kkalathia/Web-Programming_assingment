async function shouldTheyGoOutside(firstName, lastName)
{   if(firstName===undefined&&lastName===undefined||firstName===''||lastName==='')
    {
        throw "Provide value "
    }else
    if(firstName===undefined||typeof(firstName)!=='string')
    {
        throw "Enter Correct FirstName Format"
    }else if(lastName===undefined||typeof(lastName)!=='string')
    {
        throw "Enter Correct LastName Format"
    }else
    {
    const axios = require('axios');
    const weather = await axios.get('https://gist.githubusercontent.com/robherley/1b950dc4fbe9d5209de4a0be7d503801/raw/eee79bf85970b8b2b80771a66182aa488f1d7f29/weather.json')
    const {data}=await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
    
    
   for(var i=0;i<data.length;i++)
    {
        if(data[i]["firstName"]===firstName && data[i]["lastName"]===lastName)
        {
            var zp=data[i]["zip"];
                for(var j=0;j<weather.data.length;j++)
                 {
                    if(weather.data[j]["zip"]===zp)
                         {    t=weather.data[j]["temp"]
                                if(t>=34)
                                {
                                    return "Yes, " +firstName+ " should go outside."
                                }else
                                {
                                    return "No, " +firstName+ ' should not go outside.'
                                }

                             }
                    }

        
        
        }
    }
    
}
throw "No match for " +firstName+ " " +lastName

}


module.exports= 
{
    shouldTheyGoOutside    
}
