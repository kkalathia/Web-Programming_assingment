async function whereDoTheyWork(firstName, lastName)
{   if(firstName===undefined&&lastName===undefined||firstName===''||lastName==='')
{
    throw "Provide value"
}else
if(firstName===undefined||typeof(firstName)!=='string')
{
    throw "Enter Correct FirstName Format"
}else if(lastName===undefined||typeof(lastName)!=='string')
{
    throw "Enter Correct LastName Format"
}else
{
        const axios = require('axios');
        const work = await axios.get('https://gist.githubusercontent.com/robherley/61d560338443ba2a01cde3ad0cac6492/raw/8ea1be9d6adebd4bfd6cf4cc6b02ad8c5b1ca751/work.json');
        const {data}=await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
   for(var i=0;i<data.length;i++)
    {
        if(data[i]["firstName"]===firstName&& data[i]["lastName"]===lastName)
        {
            var ssn=data[i]["ssn"]
            for(var j=0;j<work.data.length;j++)
            {
                if(work.data[j]["ssn"]===ssn)
                {
                    if(work.data[j]["willBeFired"])
                    {
                        return firstName + " " + lastName +" - " + work.data[j]["jobTitle"] +" at " + work.data[j]["company"]  +". They will be fired"

                    }
                        return firstName + " " + lastName +" - "  + work.data[j]["jobTitle"] +" at "+ work.data[j]["company"] +". They will not be fired"
                }
            }

        }
    }
}
throw "No match for " +firstName+ " " +lastName
}

async function findTheHacker(ip)
{
    if(ip===undefined||typeof(ip)!=='string')
    {
        throw "Enter Correct IP format"
    }else if(ip==='')
    {
        throw "Enter IP address."
    }else 
    {
    const axios = require('axios');
    const work = await axios.get('https://gist.githubusercontent.com/robherley/61d560338443ba2a01cde3ad0cac6492/raw/8ea1be9d6adebd4bfd6cf4cc6b02ad8c5b1ca751/work.json');
    const {data}=await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');

    for(var i=0;i<work.data.length;i++)
    {
        if(work.data[i]["ip"]===ip)
        {  
             var ssn=work.data[i]["ssn"];
            for(var j=0;j<data.length;j++)
            {  
                if(data[j]["ssn"]===ssn)

                { 
                    return data[j]["firstName"] +" "+ data[j]["lastName"] +" is the hacker!"
                }


            }
        }

    }
    throw "No match found for IP address."
    }

}
module.exports= 
{
    whereDoTheyWork,
    findTheHacker    
}