const people = require("./people");
const weather = require("./weather");
const work = require("./work");
 
async function main()
{
    try{
        const peopledata = await people.getPersonById(43);
        console.log (peopledata);
    }
    catch(e)
    {
        console.log (e);
    }

    try{
    const peopledata = await people.lexIndex(2);
    console.log (peopledata);
    }
    catch(e)
    {
    console.log (e);
    } 

    try{
    const peopledata = await people.firstNameMetrics();
    console.log (peopledata);
    }
    catch(e)
    {
        console.log(e);
    }
    


    try{
        const peopledata = await weather.shouldTheyGoOutside("Scotty", "Barajaz");
        console.log (peopledata);
        }
        catch(e)
        {
            console.log(e);
        }
    
        try{
            const peopledata = await work.whereDoTheyWork("Demetra", "Durrand");
            console.log (peopledata);
            }
            catch(e)
            {
                console.log(e);
            }
            try{
                const peopledata = await work.findTheHacker("79.222.167.180");
                console.log (peopledata);
                }
                catch(e)
                {
                    console.log(e);
                }
        
}
main()
