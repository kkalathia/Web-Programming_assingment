async function getPersonById(id)
{const axios = require('axios');
const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');

    if(id<0)
    {
        throw "Enter the correct value of ID, must be greater than 0."
    }
    else
    if(id===undefined || typeof(id)!=='number')
    {
        throw "Enter correct ID format."
    }else if(id>data.length)
    {
        throw "The ID value is out of bounce."
    }else
    {
        
      for (var i = 0; i < data.length; i++)
       {
          if (data[i]["id"] === id)
          { 
          return (data[i].firstName + " " + data[i].lastName);
          }
      }
      
  }
  throw "Enter the correct ID."
}
  
async function lexIndex(index)
{const axios = require('axios');
const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
data.sort(function(a,b){var x=a.lastName;var y=b.lastName;if(x<y){return -1;}if(x>y){return 1;}return 0;})

    
    if(index<0)
    {
        throw "Enter the correct index value, must be greater than equal to 0."
    }
    else
    if(index=== undefined || typeof(index)!=='number')
    {
        throw "Enter correct Index format."
    }else  if(index>data.length-1)
    {
        throw "The Index value is out of bounce."
    }else
    { 
        for (var i = 0; i < data.length; i++)
            {
                if (index === i)
                    { 
                        return (data[i].firstName + " " + data[i].lastName);
                    }
            }
    }
    throw "Enter the correct ID."
}

async function firstNameMetrics()
{
    const axios = require('axios')
    const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json')
    var ndata={
        totalLetters :0,
        totalVowels:0,
        totalConsonants:0,
        longestName:'',
        shortestName:data[1]["firstName"]
    };
    var i=0;
    while(i<data.length)
    {
       var x=data[i]["firstName"];
       ndata.totalLetters = ndata.totalLetters + x.length;
       var a=0;
       while(a<x.length)
         { 
             if((x[a]==='a')||(x[a]==='e')||(x[a]==='i')||(x[a]==='o')||(x[a]==='u')||(x[a]==='A')||(x[a]==='E')||(x[a]==='I')||(x[a]==='O')||(x[a]==='U'))
                 {
                    ndata.totalVowels = ndata.totalVowels +1;
                }
        a++;
        }
        

        if(x.length>ndata.longestName.length)
        {
            ndata.longestName=x
        }
        if(x.length<ndata.shortestName.length){
        	ndata.shortestName = x
        }


    i++;
    }
    ndata.totalConsonants = ndata.totalLetters - ndata.totalVowels
    
    return ndata;
    

}



  module.exports= 
  {
      getPersonById,
      lexIndex,
      firstNameMetrics
  }