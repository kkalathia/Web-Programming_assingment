const express = require("express");
const app = express();
const configRoutes = require("./routes");
const bodyParser = require("body-parser");
const static = express.static(__dirname + "/public");
const exphbs = require("express-handlebars");
const session = require("express-session");
const cookieParser = require("cookie-parser");

app.use("/public", static);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

app.use(session({
    name: "AuthCookie",
    secret: "Suits is LITTTTTT",
    resave: false,
    saveUninitialized: true
}));

app.use(cookieParser());
configRoutes(app);

app.listen(3000, () => {
    console.log("Yes We got a server!");
    console.log("Server is running on http://localhost:3000");
});