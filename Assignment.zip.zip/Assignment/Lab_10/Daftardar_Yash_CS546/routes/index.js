const userData = require("../data/user");
const bcrypt = require("bcryptjs");

const express = require("express");
const router = express.Router();

let validCookies = [];


const loginUser = function(req, res, next) {
    let currentTime = new Date().toUTCString();
    let method = req.method;
    let route = req.originalUrl;
    if (!validCookies.includes(req.sessionID)) {
        console.log("[" + currentTime + "]: " + method + " " + route + " Non-Authenticated User");
    } else {

        console.log("[" + currentTime + "]: " + method + " " + route + " Authenticated User");
    }
    next();
}

router.use(loginUser);

router.post("/login", async(req, res) => {
    user = await userData.usernameToUser(req.body.username);
    if (!user) {
        res.status(401).render("templates/loginError");
        return;
    } else {
        const pwd = await bcrypt.compare(req.body.password, user.hashedPassword);
        if (!pwd) {


            res.render("templates/loginError");
            return;
        }
        validCookies.push(req.sessionID);
        currentUser = user;
        res.redirect("/private");
        return;

    }


});

router.get("/private", async(req, res) => {
    if (!req.cookies.AuthCookie) {
        res.status(403).render("templates/loginError");
        return;
    } else {

        res.render("templates/details", {
            bio: user.bio,
            username: user.username,
            profession: user.profession,
            firstName: user.firstName,
            lastName: user.lastName
        });
    }
});

router.get("/logout", async(req, res) => {
    res.clearCookie("AuthCookie");
    for (i = 0; i < validCookies.length; i++) {
        if (validCookies[i] == req.sessionID) {
            validCookies.splice(i, 1);
        }
    }
    currentUser = "";
    req.session.destroy();
    res.render("templates/logout");
    return;
});

router.get("/", async(req, res) => {
    if (req.cookies) {
        if (!validCookies.includes(req.sessionID)) {
            res.render("templates/login");
            return;

        } else {
            res.redirect("/private");
        }
    }
});

const constructorMethod = app => {
    app.use("/", router);
    app.use("*", (req, res) => {
        res.status(404);
    });
};

module.exports = constructorMethod;