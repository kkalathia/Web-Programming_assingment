const express = require("express");
const router = express.Router();
const peopleData = require("../data/search");

router.post("/", async(req, res) => {
    let findname = req.body.name;
    let err = []
    let ListData = []
    let hasErrors = false;


    try {
        ListData = await peopleData.getPersonByName(findname);


    } catch (e) {
        err.push(e)
    }
    if (err.length > 0) {
        hasErrors = true;
        res.status(400);
        res.render("main", { hasErrors: hasErrors, errors: err });
        return;


    }
    res.render("users/results", { people: ListData, name: findname });
});

module.exports = router;