const express = require('express');
const router = express.Router();
const ppldata = require("../data/search");

router.get("/:id", async(req, res) => {
    let err = [];
    let hasError = false;
    let people1 = [];
    let peoplename = []
    try {
        people1 = await ppldata.getPersonById(req.params.id);
        peoplename = people1["firstName"]
    } catch (e) {
        err.push(e)
    }
    if (err.length > 0) {
        hasErrors = true;
        res.status(400);
        res.render("main", { hasErrors: hasErrors, errors: err });
        return;


    }
    peoplename = people1["firstName"]
    res.render("users/single", { people: people1, name: peoplename });
});

module.exports = router;