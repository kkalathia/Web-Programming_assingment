const searchdata = require("./search");

module.exports = {
    search: searchdata
};