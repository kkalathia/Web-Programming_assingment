let exportedMethods = {
    async getPersonById(pid) {
        pid = parseInt(pid);
        const axios = require('axios');
        const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
        if (pid <= 0) {
            throw "Enter the correct value of ID, must be greater than 0."
        } else
        if (pid === undefined || typeof(pid) !== 'number') {
            throw "Enter correct ID format."
        } else if (pid > data.length) {
            throw "The ID value is out of bounce."
        } else {
            let datacontent = []
            for (var i = 0; i < data.length; i++) {
                if (data[i].id === pid) {
                    datacontent.push(data[i])
                    return datacontent;
                }
            }

        }
        throw "Enter the correct ID."

    },
    async getPersonByName(name) {
        const axios = require('axios');
        const data2 = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json');
        const data1 = data2.data
        let a = 0;
        var number = /^[0-9]+$/;
        let peoplefound = [];
        if (!name) {
            throw `Enter the name for search`
        }
        if (name.match(number)) {
            throw ` Enter a name string`
        }
        if (name.length === 0) {
            throw `Name must not be empty`
        }
        for (var i = 0; i < data1.length; i++) {
            if (data1[i]["firstName"].toLowerCase().includes(name.toLowerCase()) || data1[i]["lastName"].toLowerCase().includes(name.toLowerCase())) {
                a++;
                if (a <= 20) {
                    peoplefound.push(data1[i])

                }
            }
        }
        return peoplefound;

    }
}

module.exports = exportedMethods