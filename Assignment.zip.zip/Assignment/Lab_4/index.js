const animals = require("./animals");
const connection = require("./mongoConnection");

async function main()
{   //sasha create
    const Sasha= await animals.create("Sasha","Dog");
    console.log(Sasha);
    
    //lucy
    const Lucy= await animals.create("Lucy","Dog");

    //get all animals
    const all = await animals.getAll();
    console.log(all);

    //duke create
    try
    {
        const Duke= await animals.create("Duke","Walrus");
        console.log(Duke);
    }
    catch(error)
    {
        console.log(error);
    }

  //rename sasha to shashita
   try
    {
        const Shashita= await animals.rename(Sasha._id,"Sashita");
        console.log(Shashita);
    }
    catch(error)
    {
        console.log(error);
    }


    //remove Lucy
 try
    {
        const removeLucy= await animals.remove(Lucy._id);
        console.log(removeLucy);
    }
    catch(error)
    {
        console.log(error);
    }

    
    const allAnimals = await animals.getAll();
    console.log(allAnimals);
    
    
  const db = await connection();
    await db.serverConfig.close();   
}



main().catch(error => {console.log(error);});