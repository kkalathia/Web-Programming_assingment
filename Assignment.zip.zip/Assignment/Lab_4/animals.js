const mongoCollections = require('./mongoCollections');
const animals = mongoCollections.animals;
var ObjectId = require('mongodb').ObjectID

module.exports=
{
    async get(id)
    {
        if (id===undefined||id==='') 
        throw 'You must provide an id to search for';

        if(typeof(id)==='object')
        {
            const animalsCollection = await animals();
            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const animaldata = await animalsCollection.findOne({_id: id});
                if (animaldata === null)
                {
                throw `No animal with that id ${id}`;
                }
                return animaldata;
            }
            throw `You must provide proper id type for search`;
                
        }

        if(typeof(id)==='string')
        {
            const animalsCollection = await animals();
            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const animaldata = await animalsCollection.findOne({_id: id});
                if (animaldata === null)
                {
                    throw `No animal with that id ${id}`;
                }
                return animaldata;
            }
            throw `Id passed in must be a single String of 12 bytes or a string of 24 hex characters`
        }
        
        
    },
    
    async create(name, animalType)
    {
        if (name===undefined|| name==='') 
        throw 'You must provide a name for your animal';
       
        if(typeof(name)!=='string')
        throw 'You must provide propertype name of the animal';
       
        if(animalType===undefined||animalType==='')
        throw 'You must provide a animaltype for your animal';
       
        if(typeof(animalType)!=='string')
        throw 'You must provide propertype for animal type for your animal';

        const animalsCollection = await animals();
        let newAnimal=
        {
            name: name,
            animalType:animalType
        };

        const insertInfo = await animalsCollection.insertOne(newAnimal);

        if (insertInfo.insertedCount === 0)
        throw 'Could not add animal';

        const newId = insertInfo.insertedId;
        const animaldata = await animalsCollection.findOne({_id: newId});
        
        return animaldata;
    },

    async getAll()
    {
        const animalsCollection=await animals();
        const getanimal=await animalsCollection.find({}).toArray();
        return getanimal;
    },

    async remove(id)
    {
        if(id=== undefined||id==='')
        throw 'You must provide an id to remove'
        
        if(typeof(id)==='object')
        {
            const animalsCollection = await animals();
            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const animaldata = await animalsCollection.findOne({_id: id});
                const deletionInfo = await animalsCollection.deleteOne({ _id : id });
                if (deletionInfo.deletedCount === 0) 
                {
                    throw `Could not delete animal with id of ${id}`;
                }
                return animaldata;
            }
            throw `You must provide proper id type for remove`;
                
        }

        if(typeof(id)==='string')
        {
            const animalsCollection = await animals();
            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const animaldata = await animalsCollection.findOne({_id: id});
                const deletionInfo = await animalsCollection.deleteOne({ _id : id });
                if (deletionInfo.deletedCount === 0) 
                {
                    throw `Could not delete animal with id of ${id}`;
                }
                return animaldata;
            }
            throw `Id passed in must be a single String of 12 bytes or a string of 24 hex characters`
        }
        
    },
    
    async rename(id, newName)
    {
        if(id=== undefined||id==='')
        throw 'You must provide an id to rename'
        
        if(newName===undefined||newName==='')
        throw 'You must provide newName to rename the animal'
        
        if(typeof(newName)!=='string')
        throw 'You must enter proper newname type'

        if(typeof(id)==='object')
        {
            const animalsCollection = await animals();
            const updateanimal=
            {
                name:newName
            };

            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const updateinfo= await animalsCollection.updateOne({_id : id },{$set:updateanimal});
                
                if(updateinfo.modifiedCount===0)
                {
                    throw 'could not update animal successfully'
                }
                
                const animaldata = await animalsCollection.findOne({_id: id});
                return animaldata;
            }
            throw `You must provide proper id type for rename`;
                
        }

        if(typeof(id)==='string')
        {
            const animalsCollection = await animals();
            const updateanimal=
            {
                name:newName
            };

            if(ObjectId.isValid(id))
            {
                id =  ObjectId(id);
                const updateinfo= await animalsCollection.updateOne({_id : id },{$set:updateanimal});
                
                if(updateinfo.modifiedCount===0)
                {
                    throw 'could not update animal successfully'
                }
                
                const animaldata = await animalsCollection.findOne({_id: id});
                return animaldata;
            }
            throw `Id passed in must be a single String of 12 bytes or a string of 24 hex characters`
        }
        
    }


}