(function() {
    function check_prime(numb) {
        if (numb == null)
            throw "Number can not be null"
        if (Number.isNaN(numb))
            throw "You should enter the Number"
        if (numb <= 0)
            throw "Number can not be less than or equal to zero"
        if (numb === 1)
            return false;
        if (numb === 2)
            return true;
        for (let i = 2; i <= Math.sqrt(numb); i++) {
            if (numb % i == 0) {
                return false;
            }
        }
        return true;
    }
    const staticForm = document.getElementById("static-form");
    document.write(document.getElementById("number1").value)

    if (staticForm) {
        const firstNumberElement = document.getElementById("number1");
        const errorContainer = document.getElementById("error-container");
        const errorTextElement = errorContainer.getElementsByClassName("text-goes-here")[0];
        const resultContainer = document.getElementById("result-container");
        const resultTextElement = resultContainer.getElementsByClassName("text-goes-here")[0];
        staticForm.addEventListener("submit", event => {
            event.preventDefault();
            try {
                var li = document.createElement("li");
                var attempts = document.getElementById("attempts");
                errorContainer.classList.add("hidden");
                resultContainer.classList.add("hidden");
                const firstNumberValue = firstNumberElement.value
                const parsedFirstNumberValue = parseInt(firstNumberValue);
                const check_is_Prime = check_prime(parsedFirstNumberValue);
                if (check_is_Prime) {
                    li.className = "is-prime"
                    li.appendChild(document.createTextNode(parsedFirstNumberValue + " is a prime number"))
                    attempts.appendChild(li)
                } else {
                    li.className = "not-prime"
                    li.appendChild(document.createTextNode(parsedFirstNumberValue + " is not a prime number"))
                    attempts.appendChild(li)
                }
                resultContainer.classList.remove("hidden");
                event.preventDefault();
            } catch (e) {
                const message = typeof e === "string" ? e : e.message;
                errorTextElement.textContent = e;
                errorContainer.classList.remove("hidden");
            }
        });
    }
})();