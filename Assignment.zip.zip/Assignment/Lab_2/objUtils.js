function extend(...args)
 {for(var i=0;i<args.length;i++)
    {
        if(typeof(args[i]) !=="object")
        {
            throw" Object is not Object"
        }
    }

   
    if(args.length<2)
    {
        throw "Length is less than 2";
    }else if(args === undefined)
    {
        throw "Object is undefined or not type of Object";
    }
    else
    {
        args=args.reverse()
        return args.reduce((pre,cur)=>({...pre,...cur}),{});
    }
}

function smush(...args)
 {
    for(var i=0;i<args.length;i++)
    {
        if(typeof(args[i]) !=="object")
        {
            throw" Object is not Object"
        }
    }
    if(args.length<2)
    {
        throw "Length is less than 2";
    }else if(args === undefined)
    {
        throw "Object is undefined or not type of Object";
    }else{
            return args.reduce((pre,cur)=>({...pre,...cur}),{});
    }
}

function mapValues(o,func)
{
    
    if(o === undefined||typeof o !=="object")
        {
            throw "Object is undefined or not type of Object";
        }
        else if(func == null)
              throw "Function is not defined";
              else
            {for(v in o)
            {
                o[v] = func(o[v])
            }}
        return o;
        

}

module.exports={
    name:"Yash Daftardar",
    CWID:"10453472",
    extend,
    smush,
    mapValues
    
}