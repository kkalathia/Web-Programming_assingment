function head(value){
    if(Array.isArray(value))
    {
        if(value[0]!=undefined)
        return value[0]
        else 
        throw "array is empty, enter proper value in array"
    }
 throw "Please entry proper array"
}

function last(value){
    if(Array.isArray(value))
    {   value.reverse()

        if(value[0]!=undefined)
        return value[0]
        else 
        throw "array is empty, enter proper value in array"
    }
 throw "Please entry proper array"
}

function remove(arry,value){
    if(Array.isArray(arry))
    {  if(arry[0]!=undefined)
        {
            if((value<0)||(value>=arry.length)||value== undefined){
                throw "Specify proper Index value to remove element"
            }  
            else{ 
            arry.splice(value,1)
            return arry;
            }
        }  
        else 
        throw "array is empty, enter proper value in array"
    }
 throw "Please entry proper array"
}

function range(end,value)
{
    var nArray = new Array()
    if((end<=0)||(typeof(end)==='string')||(end== undefined))
    {
        throw "entered end value is worng"

    }
    else
    if(value==undefined)
    {
        for(var i=0;i<end;i++)
        {
            nArray[i]=i
        }
        return nArray
    }else
    {
            for(var i=0;i<end;i++)
            {
                nArray[i]=value
            }
            return nArray
        
    }
  
}

function countElements(array)
{
    if(Array.isArray(array))
    {
    var freq = {};
   
    for (var i=0; i<array.length;i++) {
        var value = array[i];
        if (freq[value]) {
           freq[value]++;
        } else {
           freq[value] = 1;
        }
    }

    return freq;
}
throw "entry a proper array"
}


function isEqual(arrayOne, arrayTwo)

{ 
    if(Array.isArray(arrayOne)&&Array.isArray(arrayTwo))
    {
    
        if(arrayOne.length!=arrayTwo.length)
        {
            return false
        }
        
        
            for(var i=0;i<arrayOne.length;i++)
            {
               if(arrayOne[i]==arrayTwo[i])
               {
                   continue
               }
               else
               {
                return false
               }
                
            }
            return true
        
    }
    throw "Please entry proper array"

}


module.exports={
    name:"Yash Daftardar",
    CWID:"10453472",
    
    head,
    last,
    remove,
    range,
    countElements,
    isEqual
}