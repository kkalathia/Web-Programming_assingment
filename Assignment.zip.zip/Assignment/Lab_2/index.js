const arrayUtils = require("./arrayUtils");
/* const stringUtils = require("./stringUtils");
const ObjUtils = require("./objUtils");

 //Function Array head 
try {
    // Should Pass
const headOne = arrayUtils.head([1,2,3]);
console.log('head passed successfully value is =',headOne);
} catch (e) {
console.error('head failed test case',e);
}

try {
// Should Fail
const headTwo = arrayUtils.head([]);
console.error('head passed successfully value is =',headTwo);
} catch (e) {
console.log('head failed successfully',e);
}



//Function Array Last 

try {
    // Should Pass
const lastOne = arrayUtils.last([1,2,3]);
console.log('last passed successfully value is =',lastOne);
} catch (e)
{
console.error('last failed test case',e);
}

try {
// Should Fail
const lastwo = arrayUtils.last("banana");
console.error('last passed successfully value is =',lasttwo);
} catch (e) {
console.log('last failed successfully',e);
}
 


//Function Array Remove
try {
    // Should Pass
const removeOne = arrayUtils.remove([1,2,3,4],0);
console.log('remove passed successfully value is =',removeOne);
} catch (e) {
console.error('remove failed test case',e);
}

try {
// Should Fail
const removetwo = arrayUtils.remove([1,2,3,3],-1);
console.error('remove passed successfully value is =',removetwo);
} catch (e) {
console.log('remove failed successfully',e);
}



//Function Array Range
try {
    // Should Pass
const rangeOne = arrayUtils.range(4);
console.log('Range passed successfully value is =',rangeOne);
} catch (e) {
console.error('Range failed test case because',e);
}

try {
// Should Fail
const rangetwo = arrayUtils.range();
console.error('Range passed successfully value is =',rangetwo);
} catch (e) {
console.log('Range failed successfully',e);
}


//Function Array countElements
try {
    // Should Pass
const countElementsOne = arrayUtils.countElements([13, '13', 13, 'hello', true, true]);
console.log('countElements passed successfully value is =',countElementsOne);
} catch (e) {
console.error('countElements failed test case',e);
}

try {
// Should Fail
const countElementstwo = arrayUtils.countElements();
console.error('countElements passed successfully value is =',countElementstwo);
} catch (e) {
console.log('countElements failed successfully',e);
}
 */

//Function Array isEqual
try {
    // Should Pass
const isEqualOne = arrayUtils.isEqual([1,2,3],[1,'2',3]);
console.log('isEqual value is =',isEqualOne);
} catch (e) {
console.error('isEqual failed test case',e);
}

try {
// Should Fail
const isEqualtwo = arrayUtils.isEqual([1,2,3,4],[1,3,3]);
console.error('isEqual  value is =',isEqualtwo);
} catch (e) {
console.log('isEqual failed successfully',e);
}

/* 
// function string Caps
try {
    // Should Pass
const capitalizeOne = stringUtils.capitalize("FOOBAAR");
console.log('capitalize passed successfully value is =',capitalizeOne);
} catch (e) {
console.error('capitalize failed test case',e);
}

try {
// Should Fail
const capitalizetwo = stringUtils.capitalize();
console.error('isEvqual passed successfully value is =',capitalizetwo);
} catch (e) {
console.log('capitalize failed successfully',e);
}


//Function String repeat
try {
    // Should Pass
const repeatOne = stringUtils.repeat("hi",4);
console.log('repeat passed successfully value is =',repeatOne);
} catch (e) {
console.error('repeat failed test case',e);
}

try {
// Should Fail
const repeattwo = stringUtils.repeat('abc',-1);
console.error('repeat passed successfully value is =',repeattwo);
} catch (e) {
console.log('repeat failed successfully',e);
}
/* 

//Function String countChars
try {
    // Should Pass
const countCharsOne = stringUtils.countChars('Hello, the pie is in the oven');
console.log('countChars passed successfully value is =',countCharsOne);
} catch (e) {
console.error('countChars failed test case',e);
}

try {
// Should Fail
const countCharstwo = stringUtils.countChars(123);
console.error('countChars passed successfully value is =',countCharstwo);
} catch (e) {
console.log('countChars failed successfully',e);
}  */
/* 
const first = { x: 2, y: 3};
const second = { a: 70, x: 4, z: 5 };
const third = { x: 0, y: 9, q: 10 };

 //Function Object extend
try {
    // Should Pass
const firstSecondThird1 = ObjUtils.extend(first,second,third);
console.log('extend passed successfully value is =',firstSecondThird1);
} catch (e) {
console.error('extend failed test case',e);
}

try {
// Should Fail
const firstSecondThird2 = ObjUtils.extend(first);
console.error('extend passed successfully value is =',firstSecondThird2);
} catch (e) {
console.log('extend failed successfully');
}
 
//Function Object smush
try {
    // Should Pass
const firstSecondThird1 = ObjUtils.smush(first,second,third);
console.log('smush passed successfully value is =',firstSecondThird1);
} catch (e) {
console.error('smush failed test case',e);
}

try {
// Should Fail
const firstSecondThird2 = ObjUtils.smush();

console.error('smush passed successfully value is =',firstSecondThird2);
} catch (e) {
console.log('smush failed successfully',e);
}



 //Function Object mapValues
try {
    // Should Pass
const mapvalue = ObjUtils.mapValues({ a: 1, b: 2, c: 3 }, n => n + 1);
console.log('mapvalue passed successfully value is =',mapvalue);
} catch (e) {
console.error('mapvalue failed test case',e);
}

try {
// Should Fail
const mapvalue1 = ObjUtils.mapValues({ a: 1, b: 2, c: 3 },);
console.error('mapValues passed successfully value is =',mapvalue1);
} catch (e) {
console.log('mapValues failed successfully',e);
}   */ 