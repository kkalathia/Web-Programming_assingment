function capitalize(string)
{
    if((string===undefined)||(typeof(string)!=="string"))
    {
        throw "enter a string value"
    }
    if(string=='')
    {
        return string
    }
    for(var i=0;i<string.length;i++)
    {
        if(i==0)
        {
        var str=string[i].toUpperCase();
        }
        else{
            var str1=string[i].toLowerCase()
            var str=str.concat(str1)
        }

    }
    
    return str
    
}

function repeat(string, num)
{   if((string==undefined)||typeof(string)!=="string")
{
    throw "enter a string value"
}
    
    if(num>=0)
    {
        if(num>0)
        {
            return string.repeat(num)

        }else 
        {
            return ""

        }
    }
    else
    {
        throw "enter correct number"
    }
}

function countChars(string)  {
   
    var fre = {};
    if((string==undefined)||typeof(string)!=="string")
    {
        throw "enter a string value"
    }
    for (var i=0; i<string.length;i++) {
        var v = string.charAt(i);
        if (fre[v]) {
           fre[v]++;
        } else {
           fre[v] = 1;
        }
    }

    return fre;
}

module.exports={
    name:"Yash Daftardar",
    CWID:"10453472",
    capitalize,
    repeat,
    countChars
}