const express = require('express');
const router = express.Router()

router.get('/', (req, res) => {
    res.json([{
        schoolName: "SVIS",
        degree: "Elementary School",
        favoriteClass: "Marathi",
        favoriteMemory: "We use to make tunes for the poem so the we memerise it easily"
    }, {
        schoolName: "Shri T.P. Bhatia",
        degree: "High School ",
        favoriteClass: "Chemistry",
        FavoriteMemory: "Love to work in Labs to create new substance and solution."
    }, {
        schoolName: "TCET",
        degree: "Bachelor in Computer Engineering",
        favoriteClass: "Computer Graphics",
        favoriteMemory: "The profs for CG was very funny and strict. During Submission if you are late , he use tear the assignment or if he didnt liked the diagram he would call you and overdraw the diagram till it gets torn up."
    }]);
});

module.exports = router;