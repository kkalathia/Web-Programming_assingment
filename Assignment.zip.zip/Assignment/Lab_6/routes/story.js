const express = require('express');
const router = express.Router()

router.get('/', (req, res) => {
    res.json({
        storyTitle: "Suits Season 1",
        story: "\nHarvey Specter is the best closer in New York City. \nHe's at the top of his game closing mergers, acquisitions and even divorces; it's in his blood. As a result of his success, Harvey is offered a promotion to senior partner at his firm, Pearson Hardman.With that promotion, however, Harvey will need a little help. His boss, Jessica Pearson, has enlisted him in a hunt for a new associate.\nMike Ross isn't your average Harvard Law School student... he's not even enrolled there. But that doesn't stop him from taking the bar exam for Harvard graduates as a way to make money on the side. Mike is a prodigy; simply put, he's brilliant.\nHe also has a photographic memory: if he reads something, he remembers it for life."
    });
});

module.exports = router;