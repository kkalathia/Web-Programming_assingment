const express = require('express');
const router = express.Router()

router.get('/', (req, res) => {
    res.json({
        name: "Yash Daftardar",
        cwid: "10453472",
        biography: "I am Yash Daftardar.\nI am pursing my Masters is computer Science from Stevens Institute of Technology.\nI am have completed my undergrads in Computer Science.\ Prior coming to stevens I had work experience for 2 years from LTI.\I worked as software engineer and was associated to Scania AB ",
        favoriteShows: ["Suits", "GOT", "How to get away with Murder"],
        hobbies: ["Guitar", "Cricket"]
    });
});

module.exports = router;