const mongoCollections = require('../data/mongoCollections');
const posts = mongoCollections.posts;
const animals = mongoCollections.animals;
var ObjectId = require('mongodb').ObjectID

let exportedMethods = {

    async addpost(title, author, content) {
        author = ObjectId(author);
        const postsCollection = await posts();
        const animalsCollection = await animals();
        const data = await animalsCollection.findOne({ _id: author });
        let a = []
        a = data.posts
        let b = []
        b = data.likes
        let newEntry = {
            title: title,
            content: content,
            author: author
        };
        const newInsertInformation = await postsCollection.insertOne(newEntry);
        if (newInsertInformation.insertedCount === 0)
            throw 'Insert failed!';
        const newId = newInsertInformation.insertedId;
        a.push(newId)
        b.push(newId)

        let dataid = {
            likes: b,
            posts: a

        };
        const updateInfo = await animalsCollection.updateOne({ _id: author }, { $set: dataid });
        const postdata = await postsCollection.findOne({ _id: newId });
        let dt = postdata.author;
        postdata.author = [];
        if (!postdata) throw 'User not found';
        const adata = await animalsCollection.findOne({ _id: dt })
        let arry = {
            "_id": dt,
            "name": adata.name
        }
        postdata.author.push(arry)

        return postdata;
    },

    async getAllpost() {
        const postsCollection = await posts();
        const animalsCollection = await animals();
        const getpost = await postsCollection.find({}).toArray();
        const getpost1 = await postsCollection.find({}).toArray();
        let arrtpt = []
        if (!getpost) throw 'No users in system!';
        for (let pt of getpost1) {
            const getan = await animalsCollection.find({}).toArray();
            let pp = pt.author
            pt.author = []
            for (let an of getan) {
                const aid = JSON.stringify(an._id)
                const pid = JSON.stringify(pp)
                if (aid === pid) {
                    pt.author.push({ "_id": an._id, "name": an.name })

                }
            }
            arrtpt.push(pt)
        }
        return arrtpt;
    },


    async getpostid(id) {
        id = ObjectId(id);
        const animalsCollection = await animals();
        const postsCollection = await posts();
        const data = await postsCollection.findOne({ _id: id });
        const d = await postsCollection.findOne({ _id: id });
        let dt = d.author;
        d.author = [];
        if (!data) throw 'User not found';
        const adata = await animalsCollection.findOne({ _id: dt })
        let arry = {
            "_id": dt,
            "name": adata.name
        }
        d.author.push(arry)
        return d;
    },

    async updatePost(id, updatedata) {
        const postsCollection = await posts();
        const animalsCollection = await animals();
        id = ObjectId(id);
        const pdata = await postsCollection.findOne({ _id: id });

        if ((updatedata.newTitle) && (updatedata.newContent)) {

            let updatedatainfo = {
                title: updatedata.newTitle,
                content: updatedata.newContent
            };
            const updateInfo = await postsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
                throw 'Update failed';
            const postdata = await postsCollection.findOne({ _id: id });
            let dt = postdata.author;
            postdata.author = [];
            if (!postdata) throw 'User not found';
            const adata = await animalsCollection.findOne({ _id: dt })
            let arry = {
                "_id": dt,
                "name": adata.name
            }
            postdata.author.push(arry)
            return postdata;
        }


        if (!updatedata.newContent) {
            let updatedatainfo = {
                title: updatedata.newTitle,
                content: pdata.content
            };
            const updateInfo = await postsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
                throw 'Update failed';
            const postdata = await postsCollection.findOne({ _id: id });
            let dt = postdata.author;
            postdata.author = [];
            if (!postdata) throw 'User not found';
            const adata = await animalsCollection.findOne({ _id: dt })
            let arry = {
                "_id": dt,
                "name": adata.name
            }
            postdata.author.push(arry)

            return postdata;
        }
        if (!updatedata.newTitle) {
            let updatedatainfo = {
                title: pdata.title,
                content: updatedata.newContent
            };
            const updateInfo = await postsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
                throw 'Update failed';
            const postdata = await postsCollection.findOne({ _id: id });
            let dt = postdata.author;
            postdata.author = [];
            if (!postdata) throw 'User not found';
            const adata = await animalsCollection.findOne({ _id: dt })
            let arry = {
                "_id": dt,
                "name": adata.name
            }
            postdata.author.push(arry)
            return postdata;
        }
    },
    async removepostdata(id) {
        id = ObjectId(id);
        const postsCollection = await posts();
        const animalsCollection = await animals();
        const postdata = await postsCollection.findOne({ _id: id });
        let dt = postdata.author;
        postdata.author = [];
        if (!postdata) throw 'User not found';
        const adata = await animalsCollection.findOne({ _id: dt })
        let arry = {
            "_id": dt,
            "name": adata.name
        }
        postdata.author.push(arry)

        for (let i = 0; i < adata.posts.length; i++) {
            const pid = JSON.stringify(id)
            const aid = JSON.stringify(adata.posts[i])

            if (pid === aid) {
                if (pid == JSON.stringify(id)) {
                    adata.posts.splice(i, 1)
                    adata.likes.splice(i, 1)
                }

            }
        }
        let ddt = {
            likes: adata.likes,
            posts: adata.posts
        }

        const updateInfo = await animalsCollection.updateOne({ _id: dt }, { $set: ddt });

        const deletionInfo = await postsCollection.deleteOne({ _id: id });
        if (deletionInfo.deletedCount === 0) {
            throw `Could not delete animal with id of ${id}`;
        }
        let del = {
            deleted: true,
            data: postdata
        };

        return del;

    }




}


module.exports = exportedMethods;