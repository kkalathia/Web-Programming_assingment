const mongoCollection = require('../data/mongoCollections')
const animals = mongoCollection.animals;
const posts = mongoCollection.posts;
var ObjectId = require('mongodb').ObjectID


let exportedMethods = {

    async addanimals(name, animalType) {
        if (name === '' || name === undefined) {
            throw `Provide proper name to animal`
        }

        if (animalType === '' || animalType === undefined) {
            throw `Provide proper name to animal type`
        }
        const animalsCollection = await animals();
        let newEntry = {
            name: name,
            animalType: animalType,
            likes: [],
            posts: []
        };
        const newInsertInformation = await animalsCollection.insertOne(newEntry);
        if (newInsertInformation.insertedCount === 0)
            throw 'Insert failed!';
        const newId = newInsertInformation.insertedId;
        const animaldata = await animalsCollection.findOne({ _id: newId });

        return animaldata;
    },

    async getAll() {
        const animalsCollection = await animals();
        const postsCollection = await posts();
        const getanimal = await animalsCollection.find({}).toArray();
        let arrayanimal = []
        if (!getanimal) {
            throw 'No users in system!';
        }
        for (let an of getanimal) {
            const getpost = await postsCollection.find({}).toArray();
            an.posts = [];
            an.likes = [];
            for (let pt of getpost) {
                const pid = JSON.stringify(pt.author)
                const aid = JSON.stringify(an._id)
                if (pid === aid) {
                    an.posts.push({ "_id": pt._id, "title": pt.title })
                    an.likes.push({ "_id": pt._id, "title": pt.title })

                }

            }
            arrayanimal.push(an)
        }
        return arrayanimal;
    },

    async getanimalsid(id) {
        id = ObjectId(id);
        let arry = []
        const animalsCollection = await animals();
        const postsCollection = await posts();
        const data = await animalsCollection.findOne({ _id: id });
        const d = await animalsCollection.findOne({ _id: id });
        d.posts = [];
        d.likes = [];
        if (!data) {
            throw 'User not found';
        }
        for (let i = 0; i < data.posts.length; i++) {
            const pid = data.posts[i];
            const datap = await postsCollection.findOne({ _id: pid });
            let arry = {
                "_id": pid,
                "title": datap.title
            };
            d.posts.push(arry)
            d.likes.push(arry)

        }

        return d

    },

    async updateAnimal(id, updatedata) {
        id = ObjectId(id);
        const animalsCollection = await animals();
        const data = await animalsCollection.findOne({ _id: id });

        if ((updatedata.newName) && (updatedata.newType)) {

            let updatedatainfo = {
                name: updatedata.newName,
                animalType: updatedata.newType
            };
            const animalsCollection = await animals();
            const updateInfo = await animalsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
                throw 'Update failed';
            const animaldata = await animalsCollection.findOne({ _id: id });

            return animaldata
        }
        if (!updatedata.newType) {
            let updatedatainfo = {
                name: updatedata.newName,
                animalType: data.animalType
            };
            const animalsCollection = await animals();
            const updateInfo = await animalsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount) {
                throw 'Update failed';

            }
            const animaldata = await animalsCollection.findOne({ _id: id });

            return animaldata
        }
        if (!updatedata.newName) {
            let updatedatainfo = {
                name: data.name,
                animalType: updatedata.newType
            };
            const animalsCollection = await animals();
            const updateInfo = await animalsCollection.updateOne({ _id: id }, { $set: updatedatainfo });
            if (!updateInfo.matchedCount && !updateInfo.modifiedCount)
                throw 'Update failed';
            const animaldata = await animalsCollection.findOne({ _id: id });

            return animaldata
        }
    },

    async removedata(id) {
        id = ObjectId(id);
        const animalsCollection = await animals();
        const postsCollection = await posts();
        const animaldata = await animalsCollection.findOne({ _id: id });
        for (let i = 0; i < animaldata.posts.length; i++) {
            const pid = animaldata.posts[i];

            const postsCollection = await posts();
            const deletionInfo1 = await postsCollection.deleteOne({ _id: pid });
            if (deletionInfo1.deletedCount === 0) {
                throw `Could not delete animal with id of ${id}`;
            }
        }
        const deletionInfo = await animalsCollection.deleteOne({ _id: id });
        if (deletionInfo.deletedCount === 0) {
            throw `Could not delete animal with id of ${id}`;
        } else {
            let del = {
                deleted: true,
                data: animaldata
            };
            return del;
        }

    }
}

module.exports = exportedMethods;