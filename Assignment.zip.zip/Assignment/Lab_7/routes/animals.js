const express = require("express");
const router = express.Router();
const data = require('../data');
const animalsData = data.animals;

router.get('/', async(req, res) => {

    let animalslist = await animalsData.getAll();
    res.json(animalslist);


});

router.get('/:id', async(req, res) => {
    try {
        let animalfound = await animalsData.getanimalsid(req.params.id);

        res.json(animalfound);
    } catch (e) {
        res.status(404).json({ error: 'User not found' });
    }
});

router.post('/', async(req, res) => {
    let userInfo = req.body;

    if (!userInfo) {
        res.status(400).json({ error: 'You must provide data to create a animal' });
        return;
    }

    if (!userInfo.name) {
        res.status(400).json({ error: 'You must provide a first name' });
        return;
    }

    if (!userInfo.animalType) {
        res.status(400).json({ error: 'You must provide a animal type' });
        return;
    }

    try {
        const newUser = await animalsData.addanimals(userInfo.name, userInfo.animalType);
        res.json(newUser);
    } catch (e) {
        res.sendStatus(500);
    }
});

router.put('/:id', async(req, res) => {
    let userInfo = req.body;

    if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
        res.status(400).json({ error: 'You must provide data in proper format' });
        return;
    }
    if (!userInfo.newName && !userInfo.newType) {
        res.status(400).json({ error: 'You must provide data in proper format' });
        return;
    }


    try {
        await animalsData.getanimalsid(req.params.id);
    } catch (e) {
        res.status(404).json({ error: 'Animal not found' });
        return;
    }
    try {
        const updatedUser = await animalsData.updateAnimal(req.params.id, userInfo);
        res.json(updatedUser);
    } catch (e) {
        res.sendStatus(500);
    }
});

router.delete('/:id', async(req, res) => {
    try {
        await animalsData.getanimalsid(req.params.id);
    } catch (e) {
        res.status(404).json({ error: 'Animal not found' });
        return;
    }
    try {
        let animalfound = await animalsData.removedata(req.params.id);
        res.json(animalfound);
    } catch (e) {
        res.status(404).json({ error: 'User not found ' });
    }
});



module.exports = router;