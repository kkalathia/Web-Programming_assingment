const express = require("express");
const router = express.Router();
const data = require('../data');
const postsData = data.posts;

router.get('/', async(req, res) => {
    try {
        let postslist = await postsData.getAllpost();
        res.json(postslist);

    } catch (e) {
        res.sendStatus(500);
    }
});

router.get('/:id', async(req, res) => {
    try {
        let postfound = await postsData.getpostid(req.params.id);
        res.json(postfound);
    } catch (e) {
        res.status(404).json({ error: 'User not found' });
    }
});
router.post('/', async(req, res) => {
    let userInfo = req.body;

    if (!userInfo) {
        res.status(400).json({ error: 'You must provide data to create a potst' });
        return;
    }

    if (!userInfo.title) {
        res.status(400).json({ error: 'You must provide a title' });
        return;
    }

    if (!userInfo.author) {
        res.status(400).json({ error: 'You must provide a author' });
        return;
    }
    if (!userInfo.content) {
        res.status(400).json({ error: 'You must provide a content' });
        return;
    }

    try {
        const newUser = await postsData.addpost(userInfo.title, userInfo.author, userInfo.content);
        res.json(newUser);
    } catch (e) {
        res.sendStatus(500);
    }
});

router.put('/:id', async(req, res) => {
    let userInfo = req.body;

    if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
        res.status(400).json({ error: 'You must provide data to update a post' });
        return;
    }

    if (!userInfo.newTitle && !userInfo.newContent) {
        res.status(400).json({ error: 'You must provide data in proper format' });
        return;
    }

    try {
        await postsData.getpostid(req.params.id);
    } catch (e) {
        res.status(404).json({ error: 'post not found' });
        return;
    }


    try {
        const updatedpost = await postsData.updatePost(req.params.id, userInfo);
        res.json(updatedpost);
    } catch (e) {
        res.sendStatus(500);
    }
});


router.delete('/:id', async(req, res) => {
    try {
        let postfound = await postsData.removepostdata(req.params.id);
        res.json(postfound);
    } catch (e) {
        res.status(404).json({ error: 'User not found' });
    }
});



module.exports = router;