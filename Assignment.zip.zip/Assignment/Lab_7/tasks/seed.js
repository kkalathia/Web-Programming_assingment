const dbConnection = require('../data/mongoConnection');
const data = require('../data/');
const animals = data.animals;
const posts = data.posts;
const likes = data.likes;

const main = async() => {
    const db = await dbConnection();
    await db.dropDatabase();

    const Mortimer = await animals.addanimals('Mortimer', 'Giraffe');
    const Tom = await animals.addanimals('Tom', 'Dog');
    const sher = await animals.addanimals('sher', 'lion');

    console.log('Done seeding database animal');

    const post_Mortimer = await posts.addpost("Don't ask me how the weather is up here Motimer", Mortimer._id, "It's only like a few feet higher than you. The weather isn't different. Stop harassing me.")
    const post_Tom = await posts.addpost("Don't ask me ", Mortimer._id, "It's only like a few feet higher than you. The weather isn't different. Stop harassing me.")
    const post_sher = await posts.addpost("Don't ask me sherr ", sher._id, "It's only like a few feet higher than you. The weather isn't different. Stop harassing me.")




    console.log('Done seeding database');
    await db.serverConfig.close();
};

main().catch(console.log);